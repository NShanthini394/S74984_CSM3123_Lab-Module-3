package com.example.Lab3_G2_PartF_S74984

import android.content.Context
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.core.os.bundleOf
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController

class HomeFragment : Fragment() {

    private val tagName = "LC_Home"

    override fun onAttach(context: Context) {
        super.onAttach(context)
        Log.d(tagName, "onAttach")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d(tagName, "onCreate")
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        Log.d(tagName, "onCreateView")

        return inflater.inflate(
            R.layout.fragment_home,
            container,
            false
        )
    }

    override fun onViewCreated(
        view: View,
        savedInstanceState: Bundle?
    ) {
        super.onViewCreated(view, savedInstanceState)
        Log.d(tagName, "onViewCreated")

        val btnOpenDetail =
            view.findViewById<Button>(R.id.btnOpenDetail)

        btnOpenDetail.setOnClickListener {
            val data = bundleOf("itemId" to 5)

            findNavController().navigate(
                R.id.action_home_to_detail,
                data
            )
        }
    }

    override fun onStart() {
        super.onStart()
        Log.d(tagName, "onStart")
    }

    override fun onResume() {
        super.onResume()
        Log.d(tagName, "onResume")
    }

    override fun onPause() {
        super.onPause()
        Log.d(tagName, "onPause")
    }

    override fun onStop() {
        super.onStop()
        Log.d(tagName, "onStop")
    }

    override fun onDestroyView() {
        super.onDestroyView()
        Log.d(tagName, "onDestroyView")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d(tagName, "onDestroy")
    }

    override fun onDetach() {
        super.onDetach()
        Log.d(tagName, "onDetach")
    }
}