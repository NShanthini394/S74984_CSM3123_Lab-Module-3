package com.example.Lab3_G2_PartC_S74984

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : LoggingActivity() {

    private val vm: CounterViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { view, insets ->
            val systemBars =
                insets.getInsets(WindowInsetsCompat.Type.systemBars())

            view.setPadding(
                systemBars.left,
                systemBars.top,
                systemBars.right,
                systemBars.bottom
            )

            insets
        }

        val tvCount = findViewById<TextView>(R.id.tvCount)
        val btnPlus = findViewById<Button>(R.id.btnPlus)
        val btnDialog = findViewById<Button>(R.id.btnDialog)
        val btnSecondScreen = findViewById<Button>(R.id.btnSecondScreen)
        val btnTransparent = findViewById<Button>(R.id.btnTransparent)
        val btnClose = findViewById<Button>(R.id.btnClose)

        // Display the count stored in the ViewModel.
        tvCount.text = "Count: ${vm.count}"

        btnPlus.setOnClickListener {
            vm.count++
            tvCount.text = "Count: ${vm.count}"
        }

        btnDialog.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Dialog")
                .setMessage("See Logcat")
                .setPositiveButton("OK", null)
                .show()
        }

        btnSecondScreen.setOnClickListener {
            val intent = Intent(this, SecondActivity::class.java)
            startActivity(intent)
        }

        btnTransparent.setOnClickListener {
            val intent = Intent(this, TransparentActivity::class.java)
            startActivity(intent)
        }

        btnClose.setOnClickListener {
            finish()
        }
    }
}