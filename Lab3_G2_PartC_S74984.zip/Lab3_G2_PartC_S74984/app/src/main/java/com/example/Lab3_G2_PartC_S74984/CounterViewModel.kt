package com.example.Lab3_G2_PartC_S74984

import android.util.Log
import androidx.lifecycle.ViewModel

class CounterViewModel : ViewModel() {

    var count = 0

    init {
        Log.d("LC_VM", "ViewModel created")
    }

    override fun onCleared() {
        super.onCleared()
        Log.d("LC_VM", "ViewModel destroyed")
    }
}