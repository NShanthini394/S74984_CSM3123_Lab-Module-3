package com.example.Lab3_G2_PartE_S74984

import android.util.Log
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner

class LogObserver : DefaultLifecycleObserver {

    override fun onStart(owner: LifecycleOwner) {
        Log.d("LC_OBS", "start")
    }

    override fun onStop(owner: LifecycleOwner) {
        Log.d("LC_OBS", "stop")
    }
}