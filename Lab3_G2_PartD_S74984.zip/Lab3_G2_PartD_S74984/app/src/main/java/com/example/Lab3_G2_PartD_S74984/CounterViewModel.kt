package com.example.Lab3_G2_PartD_S74984

import android.util.Log
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel

class CounterViewModel(
    private val state: SavedStateHandle
) : ViewModel() {

    var count: Int
        get() = state["count"] ?: 0
        set(value) {
            state["count"] = value
        }

    init {
        Log.d("LC_VM", "ViewModel created")
    }

    override fun onCleared() {
        super.onCleared()
        Log.d("LC_VM", "ViewModel destroyed")
    }
}